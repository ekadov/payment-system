package ru.person.service.client.dto;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.springframework.lang.Nullable;
import java.time.OffsetDateTime;
import jakarta.validation.constraints.NotNull;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * UpdateAddressRequest
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", comments = "Generator version: 7.20.0")
public class UpdateAddressRequest {

  private @Nullable String countryAlpha3;

  private @Nullable String countryAlpha2;

  private @Nullable String city;

  private @Nullable String state;

  private @Nullable String zipCode;

  private @Nullable String addressLine;

  public UpdateAddressRequest countryAlpha3(@Nullable String countryAlpha3) {
    this.countryAlpha3 = countryAlpha3;
    return this;
  }

  /**
   * Get countryAlpha3
   * @return countryAlpha3
   */
  
  @JsonProperty("countryAlpha3")
  public @Nullable String getCountryAlpha3() {
    return countryAlpha3;
  }

  public void setCountryAlpha3(@Nullable String countryAlpha3) {
    this.countryAlpha3 = countryAlpha3;
  }

  public UpdateAddressRequest countryAlpha2(@Nullable String countryAlpha2) {
    this.countryAlpha2 = countryAlpha2;
    return this;
  }

  /**
   * Get countryAlpha2
   * @return countryAlpha2
   */
  
  @JsonProperty("countryAlpha2")
  public @Nullable String getCountryAlpha2() {
    return countryAlpha2;
  }

  public void setCountryAlpha2(@Nullable String countryAlpha2) {
    this.countryAlpha2 = countryAlpha2;
  }

  public UpdateAddressRequest city(@Nullable String city) {
    this.city = city;
    return this;
  }

  /**
   * Get city
   * @return city
   */
  
  @JsonProperty("city")
  public @Nullable String getCity() {
    return city;
  }

  public void setCity(@Nullable String city) {
    this.city = city;
  }

  public UpdateAddressRequest state(@Nullable String state) {
    this.state = state;
    return this;
  }

  /**
   * Get state
   * @return state
   */
  
  @JsonProperty("state")
  public @Nullable String getState() {
    return state;
  }

  public void setState(@Nullable String state) {
    this.state = state;
  }

  public UpdateAddressRequest zipCode(@Nullable String zipCode) {
    this.zipCode = zipCode;
    return this;
  }

  /**
   * Get zipCode
   * @return zipCode
   */
  
  @JsonProperty("zipCode")
  public @Nullable String getZipCode() {
    return zipCode;
  }

  public void setZipCode(@Nullable String zipCode) {
    this.zipCode = zipCode;
  }

  public UpdateAddressRequest addressLine(@Nullable String addressLine) {
    this.addressLine = addressLine;
    return this;
  }

  /**
   * Get addressLine
   * @return addressLine
   */
  
  @JsonProperty("addressLine")
  public @Nullable String getAddressLine() {
    return addressLine;
  }

  public void setAddressLine(@Nullable String addressLine) {
    this.addressLine = addressLine;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UpdateAddressRequest updateAddressRequest = (UpdateAddressRequest) o;
    return Objects.equals(this.countryAlpha3, updateAddressRequest.countryAlpha3) &&
        Objects.equals(this.countryAlpha2, updateAddressRequest.countryAlpha2) &&
        Objects.equals(this.city, updateAddressRequest.city) &&
        Objects.equals(this.state, updateAddressRequest.state) &&
        Objects.equals(this.zipCode, updateAddressRequest.zipCode) &&
        Objects.equals(this.addressLine, updateAddressRequest.addressLine);
  }

  @Override
  public int hashCode() {
    return Objects.hash(countryAlpha3, countryAlpha2, city, state, zipCode, addressLine);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UpdateAddressRequest {\n");
    sb.append("    countryAlpha3: ").append(toIndentedString(countryAlpha3)).append("\n");
    sb.append("    countryAlpha2: ").append(toIndentedString(countryAlpha2)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    zipCode: ").append(toIndentedString(zipCode)).append("\n");
    sb.append("    addressLine: ").append(toIndentedString(addressLine)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(@Nullable Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

