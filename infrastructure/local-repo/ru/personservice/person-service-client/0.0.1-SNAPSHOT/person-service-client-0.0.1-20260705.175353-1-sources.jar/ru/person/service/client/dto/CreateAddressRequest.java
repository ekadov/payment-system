package ru.person.service.client.dto;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import org.springframework.lang.Nullable;
import java.time.OffsetDateTime;
import jakarta.validation.constraints.NotNull;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * CreateAddressRequest
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", comments = "Generator version: 7.20.0")
public class CreateAddressRequest {

  private String countryAlpha3;

  private String countryAlpha2;

  private String city;

  private @Nullable String state;

  private @Nullable String zipCode;

  private String addressLine;

  public CreateAddressRequest() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public CreateAddressRequest(String countryAlpha3, String countryAlpha2, String city, String addressLine) {
    this.countryAlpha3 = countryAlpha3;
    this.countryAlpha2 = countryAlpha2;
    this.city = city;
    this.addressLine = addressLine;
  }

  public CreateAddressRequest countryAlpha3(String countryAlpha3) {
    this.countryAlpha3 = countryAlpha3;
    return this;
  }

  /**
   * Get countryAlpha3
   * @return countryAlpha3
   */
  @NotNull
  @JsonProperty("countryAlpha3")
  public String getCountryAlpha3() {
    return countryAlpha3;
  }

  public void setCountryAlpha3(String countryAlpha3) {
    this.countryAlpha3 = countryAlpha3;
  }

  public CreateAddressRequest countryAlpha2(String countryAlpha2) {
    this.countryAlpha2 = countryAlpha2;
    return this;
  }

  /**
   * Get countryAlpha2
   * @return countryAlpha2
   */
  @NotNull
  @JsonProperty("countryAlpha2")
  public String getCountryAlpha2() {
    return countryAlpha2;
  }

  public void setCountryAlpha2(String countryAlpha2) {
    this.countryAlpha2 = countryAlpha2;
  }

  public CreateAddressRequest city(String city) {
    this.city = city;
    return this;
  }

  /**
   * Get city
   * @return city
   */
  @NotNull
  @JsonProperty("city")
  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public CreateAddressRequest state(@Nullable String state) {
    this.state = state;
    return this;
  }

  /**
   * Get state
   * @return state
   */
  
  @JsonProperty("state")
  public @Nullable String getState() {
    return state;
  }

  public void setState(@Nullable String state) {
    this.state = state;
  }

  public CreateAddressRequest zipCode(@Nullable String zipCode) {
    this.zipCode = zipCode;
    return this;
  }

  /**
   * Get zipCode
   * @return zipCode
   */
  
  @JsonProperty("zipCode")
  public @Nullable String getZipCode() {
    return zipCode;
  }

  public void setZipCode(@Nullable String zipCode) {
    this.zipCode = zipCode;
  }

  public CreateAddressRequest addressLine(String addressLine) {
    this.addressLine = addressLine;
    return this;
  }

  /**
   * Get addressLine
   * @return addressLine
   */
  @NotNull
  @JsonProperty("addressLine")
  public String getAddressLine() {
    return addressLine;
  }

  public void setAddressLine(String addressLine) {
    this.addressLine = addressLine;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CreateAddressRequest createAddressRequest = (CreateAddressRequest) o;
    return Objects.equals(this.countryAlpha3, createAddressRequest.countryAlpha3) &&
        Objects.equals(this.countryAlpha2, createAddressRequest.countryAlpha2) &&
        Objects.equals(this.city, createAddressRequest.city) &&
        Objects.equals(this.state, createAddressRequest.state) &&
        Objects.equals(this.zipCode, createAddressRequest.zipCode) &&
        Objects.equals(this.addressLine, createAddressRequest.addressLine);
  }

  @Override
  public int hashCode() {
    return Objects.hash(countryAlpha3, countryAlpha2, city, state, zipCode, addressLine);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CreateAddressRequest {\n");
    sb.append("    countryAlpha3: ").append(toIndentedString(countryAlpha3)).append("\n");
    sb.append("    countryAlpha2: ").append(toIndentedString(countryAlpha2)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    zipCode: ").append(toIndentedString(zipCode)).append("\n");
    sb.append("    addressLine: ").append(toIndentedString(addressLine)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(@Nullable Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

