package ru.person.service.client.dto;

import java.net.URI;
import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.time.OffsetDateTime;
import java.util.UUID;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.lang.Nullable;
import java.time.OffsetDateTime;
import jakarta.validation.constraints.NotNull;


import java.util.*;
import jakarta.annotation.Generated;

/**
 * IndividualResponse
 */

@Generated(value = "org.openapitools.codegen.languages.SpringCodegen", comments = "Generator version: 7.20.0")
public class IndividualResponse {

  private UUID id;

  private String passportNumber = null;

  private String phoneNumber = null;

  private String status;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private @Nullable OffsetDateTime verifiedAt = null;

  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
  private @Nullable OffsetDateTime archivedAt = null;

  public IndividualResponse() {
    super();
  }

  /**
   * Constructor with only required parameters
   */
  public IndividualResponse(UUID id, String passportNumber, String phoneNumber, String status) {
    this.id = id;
    this.passportNumber = passportNumber;
    this.phoneNumber = phoneNumber;
    this.status = status;
  }

  public IndividualResponse id(UUID id) {
    this.id = id;
    return this;
  }

  /**
   * Get id
   * @return id
   */
  @NotNull
  @JsonProperty("id")
  public UUID getId() {
    return id;
  }

  public void setId(UUID id) {
    this.id = id;
  }

  public IndividualResponse passportNumber(String passportNumber) {
    this.passportNumber = passportNumber;
    return this;
  }

  /**
   * Get passportNumber
   * @return passportNumber
   */
  @NotNull
  @JsonProperty("passportNumber")
  public String getPassportNumber() {
    return passportNumber;
  }

  public void setPassportNumber(String passportNumber) {
    this.passportNumber = passportNumber;
  }

  public IndividualResponse phoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
    return this;
  }

  /**
   * Get phoneNumber
   * @return phoneNumber
   */
  @NotNull
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  public IndividualResponse status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
   */
  @NotNull
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public IndividualResponse verifiedAt(@Nullable OffsetDateTime verifiedAt) {
    this.verifiedAt = verifiedAt;
    return this;
  }

  /**
   * Get verifiedAt
   * @return verifiedAt
   */
  
  @JsonProperty("verifiedAt")
  public @Nullable OffsetDateTime getVerifiedAt() {
    return verifiedAt;
  }

  public void setVerifiedAt(@Nullable OffsetDateTime verifiedAt) {
    this.verifiedAt = verifiedAt;
  }

  public IndividualResponse archivedAt(@Nullable OffsetDateTime archivedAt) {
    this.archivedAt = archivedAt;
    return this;
  }

  /**
   * Get archivedAt
   * @return archivedAt
   */
  
  @JsonProperty("archivedAt")
  public @Nullable OffsetDateTime getArchivedAt() {
    return archivedAt;
  }

  public void setArchivedAt(@Nullable OffsetDateTime archivedAt) {
    this.archivedAt = archivedAt;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    IndividualResponse individualResponse = (IndividualResponse) o;
    return Objects.equals(this.id, individualResponse.id) &&
        Objects.equals(this.passportNumber, individualResponse.passportNumber) &&
        Objects.equals(this.phoneNumber, individualResponse.phoneNumber) &&
        Objects.equals(this.status, individualResponse.status) &&
        Objects.equals(this.verifiedAt, individualResponse.verifiedAt) &&
        Objects.equals(this.archivedAt, individualResponse.archivedAt);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, passportNumber, phoneNumber, status, verifiedAt, archivedAt);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class IndividualResponse {\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    passportNumber: ").append(toIndentedString(passportNumber)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    verifiedAt: ").append(toIndentedString(verifiedAt)).append("\n");
    sb.append("    archivedAt: ").append(toIndentedString(archivedAt)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(@Nullable Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

